export const phoneNumbers = {
    "NatLatamDev": "wvywhtspp_5511937418840_",
    "NatLatamPrd": "wvywhtspp_5511930380000_",
    "NatBrDev": "wvywhtspp_5511930370000_",
    "NatBrPrd": "wvywhtspp_5511930360000_",
    "AvonHispDev": "wvywhtspp_5511933528111_",
    "AvonHispPrd": "wvywhtspp_5511974223520_"
}